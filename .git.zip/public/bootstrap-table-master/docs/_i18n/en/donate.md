Bootstrap Table is a free plug-in which be made in my spare time.

If your project get the help from Bootstrap Table, you can donate to Bootstrap Table.

With your help, I believe that I will continue to strive to let Bootstrap Table be better.