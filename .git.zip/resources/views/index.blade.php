<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Darkcloud</title>
  <base href="/">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="favicon.ico">

  <!-- working? just copied from last template -->
  <!-- <link rel="stylesheet" type="text/css" href="/css/app.css" /> -->
</head>
<body>
  <app-root></app-root>
<script type="text/javascript" src="app/inline.bundle.js"></script><script type="text/javascript" src="app/polyfills.bundle.js"></script><script type="text/javascript" src="app/styles.bundle.js"></script><script type="text/javascript" src="app/vendor.bundle.js"></script><script type="text/javascript" src="app/main.bundle.js"></script></body>
</html>
