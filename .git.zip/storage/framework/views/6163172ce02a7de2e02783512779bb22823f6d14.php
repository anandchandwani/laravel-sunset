<?php $__env->startComponent('base'); ?>

<div class="container">
    <div class="alert alert-danger" role="alert">
        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
        Here you can add an IP to the blacklist manually
    </div>

    <form class="form-inline" action="" method="post">
        <label>IP:<input type="text" name="ip" class="form-control"></label>
        <button type="submit" class="btn btn-danger">
            Add IPs to Blacklist
        </button>
    </form>

</div>
<?php if(isset($status) and isset($ip)): ?>
    <?php if($status == 'success'): ?>
        <script>alert('IP <?php echo e($ip); ?> was added to blacklist');</script>
    <?php endif; ?>
    <?php if($status == 'fail'): ?>
        <script>alert('Cannot add IP <?php echo e($ip); ?> to blacklist');</script>
    <?php endif; ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>