<?php $__env->startComponent('base'); ?>
    <?php echo $__env->make('apps-table', ['apps' => $apps], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <hr>
    <?php echo $__env->make('ip-table', ['ips' => $ips, 'apps' => $apps], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <hr>
    <?php echo $__env->make('requests-table', ['requests' => $requests], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->renderComponent(); ?>